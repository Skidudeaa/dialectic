# @dark-roast/companion-ui 0.1.0

React 19 presentation components extracted from the Dark Roast Companion workbench.

```tsx
import '@dark-roast/companion-ui/css'
import { ComposerFrame, ResponseCard, ReviewButton, ContextInspector, RichText } from '@dark-roast/companion-ui'

<ComposerFrame tone="editing"><YourExistingComposer /></ComposerFrame>
<ResponseCard streaming={streaming}><YourExistingMessage /></ResponseCard>
<ReviewButton intent="accept" disabled={saving} onClick={accept}>Accept</ReviewButton>
<ContextInspector title="Sources" sources={[{id: 'source', label: 'Source', onNavigate: openSource}]} />
<RichText text={markdown} onUseContext={(code, language) => attach(code, language)} />
```

- Exports: `CompanionScope`, `ComposerFrame`, `ResponseCard`, `ReviewButton`, `ProposalCard`, `ContextInspector`, `CodeBlock`, `RichText` and their TypeScript prop types.
- CSS is opt-in and scoped to `dr-companion` / `drc-*`; no body reset or global palette changes.
- The package owns presentation only. Authentication, network calls, storage, uploads, and proposal state remain with the consumer.
- `ReviewButton` forwards native button props. It never resolves, rejects, or executes anything by itself.
- `ContextInspector` preserves non-navigable sources. Details/actions render only when supplied.
- `RichText` disables raw HTML and turns remote images into links. `CodeBlock` never executes code; copy errors remain visible. A supplied `onCopy` owns success reporting.
- For custom Markdown pipelines, use `ResponseCard` and keep the existing renderer, mentions, links, and passage markers.
- Import the CSS once. DM Sans is bundled by the consuming application from the declared font dependency.
- Build: `npm ci && npm run build`; verify: `npm test`; package: `npm pack`.
- Version 0.1.0 is an initial local distribution; no public registry publication is required.
